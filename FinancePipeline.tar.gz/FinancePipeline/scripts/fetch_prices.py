#!/usr/bin/env python3
"""
Fetch Price Data from APIs
Door 865: Financial Data Pipeline - SQLite Edition
"""

import sys
import os
import argparse
from typing import List

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.pipeline import FinancePipeline


def load_watchlist(path: str) -> List[str]:
    """Load symbols from watchlist file (one per line)"""
    with open(path, 'r') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]


def main():
    parser = argparse.ArgumentParser(
        description='Fetch price data from Alpha Vantage or other APIs'
    )
    parser.add_argument(
        '--symbols',
        help='Comma-separated list of symbols (e.g., AAPL,MSFT,GOOGL)',
        default=None
    )
    parser.add_argument(
        '--watchlist',
        help='Path to watchlist file (one symbol per line)',
        default=None
    )
    parser.add_argument(
        '--watchlist-name',
        help='Load symbols from named watchlist in database',
        default=None
    )
    parser.add_argument(
        '--outputsize',
        choices=['compact', 'full'],
        default='compact',
        help='compact=100 days, full=20 years (default: compact)'
    )
    parser.add_argument(
        '--delay',
        type=int,
        help='Seconds to wait between API calls (default: from config)',
        default=None
    )
    parser.add_argument(
        '--source',
        choices=['alpha_vantage', 'finnhub'],
        default='alpha_vantage',
        help='Data source API (default: alpha_vantage)'
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("Financial Data Pipeline - Price Data Fetcher")
    print("=" * 60)
    
    # Initialize pipeline
    pipeline = FinancePipeline()
    
    # Check API key
    if args.source not in pipeline.api_keys or not pipeline.api_keys[args.source]:
        print(f"\nError: {args.source} API key not configured")
        print(f"Edit config/config.json and add your API key")
        return 1
    
    # Get symbols to fetch
    symbols = []
    
    if args.symbols:
        symbols = [s.strip() for s in args.symbols.split(',')]
    elif args.watchlist:
        symbols = load_watchlist(args.watchlist)
        print(f"\nLoaded {len(symbols)} symbols from {args.watchlist}")
    elif args.watchlist_name:
        symbols = pipeline.get_watchlist(args.watchlist_name)
        print(f"\nLoaded {len(symbols)} symbols from watchlist '{args.watchlist_name}'")
    else:
        # Use default watchlist from config
        default = pipeline.config.get('watchlists', {}).get('default', [])
        if default:
            symbols = default
            print(f"\nUsing default watchlist ({len(symbols)} symbols)")
        else:
            print("\nError: No symbols specified")
            print("Use --symbols, --watchlist, or --watchlist-name")
            return 1
    
    if not symbols:
        print("No symbols to fetch")
        return 1
    
    print(f"\nFetching {args.outputsize} data for {len(symbols)} symbols...")
    print(f"Source: {args.source}")
    
    # Check rate limits
    if args.source == 'alpha_vantage':
        usage = pipeline.get_api_usage('alpha_vantage', hours=24)
        limit = pipeline.config['rate_limits']['alpha_vantage']['calls_per_day']
        remaining = limit - usage
        
        print(f"API usage: {usage}/{limit} calls today ({remaining} remaining)")
        
        if len(symbols) > remaining:
            print(f"\n⚠ Warning: Requesting {len(symbols)} symbols but only {remaining} calls remaining")
            response = input("Continue anyway? (y/N): ")
            if response.lower() != 'y':
                print("Aborted")
                return 0
    
    # Fetch data
    results = pipeline.bulk_load_symbols(symbols, delay=args.delay)
    
    # Show results
    print("\n" + "=" * 60)
    successful = sum(1 for r in results if r['success'])
    failed = len(results) - successful
    
    print(f"✓ Successfully loaded: {successful}/{len(results)} symbols")
    
    if failed > 0:
        print(f"✗ Failed: {failed} symbols")
        print("\nFailed symbols:")
        for r in results:
            if not r['success']:
                print(f"  {r['symbol']}: {r.get('error', 'Unknown error')}")
    
    # Show data summary
    total_records = pipeline.query("""
        SELECT COUNT(*) as count FROM daily_prices
    """)['count'].iloc[0]
    
    latest_date = pipeline.query("""
        SELECT MAX(timestamp) as latest FROM daily_prices
    """)['latest'].iloc[0]
    
    print(f"\nDatabase now contains:")
    print(f"  {total_records:,} price records")
    print(f"  Latest data: {latest_date}")
    
    print("\n" + "=" * 60)
    print("Next steps:")
    print("  python scripts/query.py --sector Technology")
    print("  python scripts/fetch_macro.py")
    print("=" * 60)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
